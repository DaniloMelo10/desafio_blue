import React from 'react';
import { View } from 'react-native';

import TextInput1 from '../TextInput/TextInput1';
import TextInput2 from '../TextInput/TextInput2';
import Button2 from '../Button/Button2';

export default function CriarH() {
  return (
    
    <View>
        <TextInput1/>
        <TextInput2/>
        <Button2/>

    </View>

   

    

  );
}
