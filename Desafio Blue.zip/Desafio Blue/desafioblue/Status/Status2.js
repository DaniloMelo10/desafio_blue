import React from 'react';
import { StyleSheet, View, Button, Image } from 'react-native';
import Title2 from '../Title/Title2';
import List2 from '../List/List2';



export default function Status2() {
    return (

        <>
            <Title2/>
            <List2/>
            
            <Image style={styles.image2} source={require('../progresso.png')} />
            <Image style={styles.image} source={require('../grafico.png')} />
        </>

);
}
 const styles = StyleSheet.create({
     image: {
         width: 400,
         height: 400,
     },
     image2: {
         width: 50,
         height: 50,
     }
 });
