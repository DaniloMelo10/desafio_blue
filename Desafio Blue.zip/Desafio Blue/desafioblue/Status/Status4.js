import React from 'react';
import { StyleSheet, View, Button, Image } from 'react-native';
import Title4 from '../Title/Title4';
import List4 from '../List/List4';



export default function Status4() {
    return (

        <>
            <Title4/>
            <List4/>
            
            <Image style={styles.image2} source={require('../progresso.png')} />
            <Image style={styles.image} source={require('../grafico.png')} />
        </>

);
}
 const styles = StyleSheet.create({
     image: {
         width: 400,
         height: 400,
     },
     image2: {
         width: 50,
         height: 50,
     }
 });