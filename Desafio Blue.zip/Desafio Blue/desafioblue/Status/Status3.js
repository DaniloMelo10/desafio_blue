import React from 'react';
import { StyleSheet, View, Button, Image } from 'react-native';
import Title3 from '../Title/Title3';
import List3 from '../List/List3';



export default function Status3() {
    return (

        <>
            <Title3/>
            <List3/>
            
            <Image style={styles.image2} source={require('../progresso.png')} />
            <Image style={styles.image} source={require('../grafico.png')} />
        </>

);
}
 const styles = StyleSheet.create({
     image: {
         width: 400,
         height: 400,
     },
     image2: {
         width: 50,
         height: 50,
     }
 });