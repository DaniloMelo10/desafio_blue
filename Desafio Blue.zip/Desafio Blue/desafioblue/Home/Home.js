import React from 'react';
import  { Button } from 'react-native-paper';

import Box from '../Box/Box';
import Box2 from '../Box/Box2';
import Box3 from '../Box/Box3';
import Box4 from '../Box/Box4';

export default function Home(props) {
    console.log(props);
    return (
        <>
        <Box/>
        <Box2/>
        <Box3/>
        <Box4/>
        <Button mode="contained" onPress={()=>props.navigation.navigate('CriarHábito')}>
            Crie seu hábito
        </Button>
        <Button mode="text" onPress={()=>props.navigation.navigate('Status1')}>
            Acompanhar - Estudar
        </Button>
        <Button mode="text" onPress={()=>props.navigation.navigate('Status2')}>
            Acompanhar - Correr
        </Button>
        <Button mode="text" onPress={()=>props.navigation.navigate('Status3')}>
            Acompanhar - Meditar
        </Button>
        <Button mode="text" onPress={()=>props.navigation.navigate('Status4')}>
            Acompanhar - 2L de água
        </Button>
        
        </>
    )
}