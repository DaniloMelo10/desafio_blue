import * as React from 'react';
import { Card, IconButton, Colors } from 'react-native-paper';

const Box2 = () => (
    <Card.Title
    title="Correr"
    subtitle="seg   |   ter   |   qua   |   qui   |   sex   |   sab   |   dom"
    right={(props) => <IconButton {...props} icon="folder" color={Colors.blue500} onPress={() => {}} />}
  />
);

export default Box2;