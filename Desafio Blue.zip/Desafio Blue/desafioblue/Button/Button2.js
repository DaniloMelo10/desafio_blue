import * as React from 'react';
import { Button } from 'react-native-paper';

const Button2 = () => (
  <Button mode="contained" onPress={() => console.log('Pressed')}>
    Salvar
  </Button>
);

export default Button2;