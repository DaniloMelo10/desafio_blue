import * as React from 'react';
import { Card } from 'react-native-paper';

const Title4 = () => (
  <Card.Title
    title="2L de água"
    subtitle="Visão geral"
  />
);

export default Title4;