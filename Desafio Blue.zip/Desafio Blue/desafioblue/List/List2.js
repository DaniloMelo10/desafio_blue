import * as React from 'react';
import { List } from 'react-native-paper';

const List2 = () => (
  <>
  <List.Item
    title="    85%                   85%                   85%"
    description="Pontuação             Semanal                 Mensal"
  />
</>
);

export default List2;