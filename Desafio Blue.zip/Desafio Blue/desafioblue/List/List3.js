import * as React from 'react';
import { List } from 'react-native-paper';

const List3 = () => (
  <>
  <List.Item
    title="    85%                   85%                   85%"
    description="Pontuação             Semanal                 Mensal"
  />
</>
);

export default List3;