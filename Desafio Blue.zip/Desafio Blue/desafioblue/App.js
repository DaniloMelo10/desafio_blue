import React from 'react';
import { StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Home from './Home/Home';
import CriarHábito from './CriarHábito/CriarHábito';
import Status1 from './Status/Status1';
import Status2 from './Status/Status2';
import Status3 from './Status/Status3';
import Status4 from './Status/Status4';

export default function App() {

  const Stack = createStackNavigator();

  return (

    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Seus Hábitos" component={Home} />
        <Stack.Screen name="CriarHábito" component={CriarHábito} />
        <Stack.Screen name="Status1" component={Status1} />
        <Stack.Screen name="Status2" component={Status2} />
        <Stack.Screen name="Status3" component={Status3} />
        <Stack.Screen name="Status4" component={Status4} />
        
      </Stack.Navigator>
    </NavigationContainer>

  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
