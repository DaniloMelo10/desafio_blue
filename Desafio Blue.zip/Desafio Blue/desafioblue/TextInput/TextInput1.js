import * as React from 'react';
import { TextInput } from 'react-native-paper';

export default class TextInput1 extends React.Component {
  state = {
    text: ''
  };

  render(){
    return (
      <TextInput
        label='Nome do hábito'
        value={this.state.text}
        onChangeText={text => this.setState({ text })}
      />
    );
  }
}